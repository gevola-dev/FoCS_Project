print('Hello')

a = 10
print(f'a + 1 = {a+1}')

for i in range(10):
    print(i)